package com.jaggaer.sf.client.sfcase;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.util.List;

import javax.xml.bind.JAXBElement;

import java.io.IOException;

import com.jaggaer.sf.client.sfcase.model.Payload;
import com.sforce.soap.enterprise.DeleteResult;
import com.sforce.soap.enterprise.DescribeGlobalResult;
import com.sforce.soap.enterprise.DescribeGlobalSObjectResult;
import com.sforce.soap.enterprise.DescribeSObjectResult;
import com.sforce.soap.enterprise.EnterpriseConnection;
import com.sforce.soap.enterprise.Error;
import com.sforce.soap.enterprise.Field;
import com.sforce.soap.enterprise.FieldType;
import com.sforce.soap.enterprise.GetUserInfoResult;
import com.sforce.soap.enterprise.LoginResult;
import com.sforce.soap.enterprise.PicklistEntry;
import com.sforce.soap.enterprise.QueryResult;
import com.sforce.soap.enterprise.SaveResult;
import com.sforce.soap.enterprise.sobject.Account;
import com.sforce.soap.enterprise.sobject.Case;
import com.sforce.soap.enterprise.sobject.Contact;
import com.sforce.soap.enterprise.sobject.SObject;
import com.sforce.ws.ConnectorConfig;
import com.sforce.ws.ConnectionException;

public class CreateCase {

   private static BufferedReader reader = new BufferedReader(
         new InputStreamReader(System.in));

    private String userName;
    private String password;
   
    private Payload payload;
    
    
    public Payload getPayload() {
		return payload;
	}

	public void setPayload(Payload payload) {
		this.payload = payload;
	}

	public String getUserName() {
	   return userName;
    }
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	EnterpriseConnection connection;
   String authEndPoint = "";

   public static void main(String[] args) {
      CreateCase sample = new CreateCase("https://techindians4-dev-ed.my.salesforce.com/services/Soap/c/24.0");
      sample.run();
   }

   public void run() {
      if (login()) {
    	  String result = createCase(payload.getContactID(),
    			  payload.getApplicationUser(), 
    			  payload.getCaseDescription(),
    			  "Created At " + LocalDateTime.now());
	      logout();
      }
   }

   public CreateCase(String authEndPoint) {
      this.authEndPoint = authEndPoint;
   }

   private String getUserInput(String prompt) {
      String result = "";
      try {
         System.out.print(prompt);
         result = reader.readLine();
      } catch (IOException ioe) {
         ioe.printStackTrace();
      }

      return result;
   }

   
   
   private boolean login() {
      boolean success = false;
      try {
         ConnectorConfig config = new ConnectorConfig();
         config.setUsername(userName);
         config.setPassword(password);

         System.out.println("AuthEndPoint: " + authEndPoint);
         config.setAuthEndpoint(authEndPoint);

         connection = new EnterpriseConnection(config);

         success = true;
      } catch (ConnectionException ce) {
         ce.printStackTrace();
      } 

      return success;
   }

 
   private void logout() {
      try {
         connection.logout();
         System.out.println("Logged out.");
      } catch (ConnectionException ce) {
         ce.printStackTrace();
      }
   }

 
   public String createCase(String contactID, String personalEmail,
		   					String description, String subject) {
	   String login = login()?"Success":"Fail";
	   
	   if("Fail".equals(login)) {
		   return "Unable to create case";
	   }
	  	
	   Case caseObject = new Case();
       caseObject.setContactId(contactID); 
       caseObject.setDescription(description); 
       caseObject.setSubject(subject); 
       SObject [] cs = new SObject[1];
       cs[0] = caseObject;
       
         try {
			SaveResult[]res= connection.create(cs);
			System.out.println(res.toString());
		} catch (ConnectionException e) {
			e.printStackTrace();
		}
         
        return "Case has been successfully created";
   }
   
   private void querySample() {
      String soqlQuery = "SELECT Id, FirstName, LastName FROM Contact";
      try {
         QueryResult qr = connection.query(soqlQuery);
         boolean done = false;

         if (qr.getSize() > 0) {
            System.out.println("\nLogged-in user can see "
                  + qr.getRecords().length + " contact records.");

            while (!done) {
               System.out.println("");
               SObject[] records = qr.getRecords();
               for (int i = 0; i < records.length; ++i) {
                  Contact con = (Contact) records[i];
                  String fName = con.getFirstName();
                  String lName = con.getLastName();

                  System.out.println(con.getId());
                  if (fName == null) {
                     System.out.println("Contact " + (i + 1) + ": " + lName);
                  } else {
                     System.out.println("Contact " + (i + 1) + ": " + fName
                           + " " + lName);
                  }
               }

               if (qr.isDone()) {
                  done = true;
               } else {
                  qr = connection.queryMore(qr.getQueryLocator());
               }
            }
         } else {
            System.out.println("No records found.");
         }
       
         
      } catch (ConnectionException ce) {
         ce.printStackTrace();
      }
   }
}

//JAXBElement<String> contactId = 
//objectFactory.createUserContactId(contactID);
//
//JAXBElement<String> emailId = 
//objectFactory.createContactEmail(personalEmail);
//
//JAXBElement<String> descriptionText = 
//objectFactory.createContactDescription(description);
//
//JAXBElement<String> subjectText = 
//objectFactory.createCaseSubject(subject);
