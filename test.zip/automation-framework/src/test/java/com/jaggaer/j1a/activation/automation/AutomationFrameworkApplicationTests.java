package com.jaggaer.j1a.activation.automation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomationFrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
