package com.jaggaer.j1a.activation.automation.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("jonea")
public class JaggaerOneAnalytics {
	private String instanceURL;
	private String instanceUserName;
	
	@Value("${INSTANCE_PASSWORD}")
	private String instancePassword="txt1pwd";
	private String instanceActionURL;

	public String getInstanceActionURL() {
		return instanceActionURL;
	}
	public void setInstanceActionURL(String instanceActionURL) {
		this.instanceActionURL = instanceActionURL;
	}
	public String getInstanceURL() {
		return instanceURL;
	}
	public void setInstanceURL(String instanceURL) {
		this.instanceURL = instanceURL;
	}
	public String getInstanceUserName() {
		return instanceUserName;
	}
	public void setInstanceUserName(String instanceUserName) {
		this.instanceUserName = instanceUserName;
	}
	public String getInstancePassword() {
		return instancePassword;
	}
	public void setInstancePassword(String instancePassword) {
		this.instancePassword = instancePassword;
	}
}
