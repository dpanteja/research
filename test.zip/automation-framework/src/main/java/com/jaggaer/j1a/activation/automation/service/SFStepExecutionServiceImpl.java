package com.jaggaer.j1a.activation.automation.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.ff4j.FF4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jaggaer.j1a.activation.automation.model.AutomationConstants;
import com.jaggaer.j1a.activation.automation.model.SalesForcePayload;
import com.jaggaer.j1a.activation.automation.model.StepExecutionContext;
import com.jaggaer.j1a.activation.automation.model.StepExecutionResponse;
import com.jaggaer.j1a.activation.automation.properties.SalesForce;
import com.jaggaer.sf.client.sfcase.CreateCase;

@Component
public class SFStepExecutionServiceImpl 
		implements SingleStepExecution<SalesForcePayload>{
	
	private static org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(SFStepExecutionServiceImpl.class); 

	@Autowired
	private SalesForce salesForce;

	@Autowired
	private FF4j ff4j;
	
	private StepExecutionContext<SalesForcePayload> executionContext;
	
	public SFStepExecutionServiceImpl(SalesForce salesForce) {
		this.salesForce = salesForce;
	}
	
	public SFStepExecutionServiceImpl() {
		
	}
	
	private void initializeProperties() {
		logger.info("Setting up parameters for execution...");
		Map<String, String> sfSteps = new HashMap<>();

		sfSteps.put("TARGETURL", salesForce.getEndPoint());

		sfSteps.put("USERNAME", salesForce.getUserName());
		sfSteps.put("PASSWORD", salesForce.getPassword());
		
		SalesForcePayload sfPayload = new SalesForcePayload();
		sfPayload.setContactID("0035i00000CLUG3AAP");
		sfPayload.setCaseDescription("This is case created from framework on " + LocalDateTime.now());
		sfPayload.setApplicationUser("dandapani.parasa@techndians.com");

		executionContext = new StepExecutionContext<>();
		executionContext.setPayload(sfPayload);
		executionContext.setExecutionProperties(sfSteps);

	}
	
	public SFStepExecutionServiceImpl(StepExecutionContext<SalesForcePayload> executionContext) {
		this.executionContext = executionContext;
	}

	@Override
	public StepExecutionResponse execute() {
			logger.info("Starting execution....");
		 	StepExecutionResponse stepResponse = new StepExecutionResponse();
			initializeProperties();
		 	
//			CreateCase sfCase = new CreateCase(
//					executionContext.getExecutionProperties().get("TARGETURL"));

			CreateCase sfCase = new CreateCase(
					ff4j.getPropertiesStore().readProperty(AutomationConstants.SF_URL_PROPERTY).getValue().toString());

			sfCase.setUserName(executionContext.getExecutionProperties().get("USERNAME"));
			sfCase.setPassword(executionContext.getExecutionProperties().get("PASSWORD"));

			SalesForcePayload sfPayload = executionContext.getPayload();
			
			String response = sfCase.createCase(sfPayload.getContactID(), sfPayload.getApplicationUser(), sfPayload.getCaseDescription(), null);

			stepResponse.setResponse(response);
			
			logger.info("Execution Completed....");
			return stepResponse;
	}
}
