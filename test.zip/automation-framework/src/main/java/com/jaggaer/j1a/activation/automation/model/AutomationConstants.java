package com.jaggaer.j1a.activation.automation.model;

public class AutomationConstants {
    public static final String FEATURE_CONFIGURE_JD = "configureJD";
    public static final String FEATURE_CONFIGURE_JI   = "configureJI";
    public static final String SF_URL_PROPERTY = "salesforceURL";
    public static final String JA_INSTANCE_URL = "instanceURL";
    public static final String JA_ACTION_URL = "actionURL";
}
