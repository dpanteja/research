package com.jaggaer.j1a.activation.automation.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "jiconfig") 
@ConfigurationPropertiesScan
public class JIConfigPayload {
	private String userAct="SAVE";
	private String groupId;
	private String[] name;
	private String[] dbConfig;
	private String[] updated;
	
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String[] getName() {
		return name;
	}
	public void setName(String[] name) {
		this.name = name;
	}
	public String[] getDbConfig() {
		return dbConfig;
	}
	public void setDbConfig(String[] dbConfig) {
		this.dbConfig = dbConfig;
	}
	public String[] getUpdated() {
		return updated;
	}
	public void setUpdated(String[] updated) {
		this.updated = updated;
	}
	
	public String getPOSTBody() {
		StringBuilder sb = new StringBuilder();
		sb.append("userAct=");
		sb.append(userAct);
		sb.append("&");
		sb.append("groupId=");
		sb.append(groupId);
		sb.append("&");
		for(var currentName:name) {
			sb.append("NAME=");
			sb.append(groupId);
			sb.append(".");
			sb.append(currentName);
			sb.append("&");
		}
		for(var currentConfig:dbConfig) {
			sb.append("dbConfig=");
			sb.append(currentConfig);
			sb.append("&");
		}
		for(int j=1;j<=dbConfig.length;j++) {
			sb.append("UPDATED=");
			sb.append("1");
			sb.append("&");
		}
		
		return sb.toString();
	}
}
