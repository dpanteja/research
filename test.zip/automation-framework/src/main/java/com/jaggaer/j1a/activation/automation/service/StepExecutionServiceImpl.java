package com.jaggaer.j1a.activation.automation.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jaggaer.j1a.activation.automation.model.ActivationExecutionSteps;
import com.jaggaer.j1a.activation.automation.model.StepExecutionResponse;


@Component
public class StepExecutionServiceImpl<T> 
		implements StepExecutionService{
	
	@Autowired
	private ActivationExecutionSteps<T> activationSteps;

	@Override
	public List<StepExecutionResponse> execute() {
		List<StepExecutionResponse> responses = new ArrayList<>();
		
		for(SingleStepExecution<T> currentStep:activationSteps.getSteps()) {
			StepExecutionResponse stepResponse = 
					currentStep.execute();
			
			
			responses.add(stepResponse);
		}
		
		
		return responses;
	}

}
