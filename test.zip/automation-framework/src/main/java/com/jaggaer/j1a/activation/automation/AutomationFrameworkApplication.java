package com.jaggaer.j1a.activation.automation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomationFrameworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomationFrameworkApplication.class, args);
	}

}
