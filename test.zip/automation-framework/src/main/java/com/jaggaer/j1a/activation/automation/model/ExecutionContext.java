package com.jaggaer.j1a.activation.automation.model;

public interface ExecutionContext{

	
}
