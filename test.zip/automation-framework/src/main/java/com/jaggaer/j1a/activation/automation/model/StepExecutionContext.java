package com.jaggaer.j1a.activation.automation.model;

import java.io.Serializable;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class StepExecutionContext<T> implements ExecutionContext, Serializable {

	private static final long serialVersionUID = 101L;

	private Map<String, String> executionProperties;

	private transient T payload;
	
	public T getPayload() {
		return payload;
	}

	public void setPayload(T payload) {
		this.payload = payload;
	}

	public Map<String, String> getExecutionProperties() {
		return executionProperties;
	}

	public void setExecutionProperties(Map<String, String> executionProperties) {
		this.executionProperties = executionProperties;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
