package com.jaggaer.j1a.activation.automation.service;

import java.util.List;

import com.jaggaer.j1a.activation.automation.model.StepExecutionResponse;

public interface StepExecutionService {
	public List<StepExecutionResponse> execute();
}
