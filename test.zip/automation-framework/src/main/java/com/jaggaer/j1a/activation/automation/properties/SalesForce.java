package com.jaggaer.j1a.activation.automation.properties;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("salesforce")
public class SalesForce implements Serializable{
	private static final long serialVersionUID = 1L;

	private String endPoint;
	private String userName;
	
	@Value("${SF_PASSWORD}")
	private String password="P1v2t3l4!DD6PlctOn4I46vMSkgf6hpVD";
	
	public String getEndPoint() {
		return endPoint;
	}
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
