package com.jaggaer.j1a.activation.automation.model;

import org.springframework.stereotype.Component;

@Component
public class StepExecutionRequest<T> {

	T requestPayLoad;

	public T getRequestPayLoad() {
		return requestPayLoad;
	}

	public void setRequestPayLoad(T requestPayLoad) {
		this.requestPayLoad = requestPayLoad;
	}

	
}
