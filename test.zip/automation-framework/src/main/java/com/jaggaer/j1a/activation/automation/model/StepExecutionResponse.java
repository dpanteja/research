package com.jaggaer.j1a.activation.automation.model;

import org.springframework.stereotype.Component;

@Component
public class StepExecutionResponse {

	private String response;

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
}
