package com.jaggaer.j1a.activation.automation.service;

import com.jaggaer.j1a.activation.automation.model.StepExecutionResponse;

public interface SingleStepExecution<T> {
	
	public StepExecutionResponse execute();

}
