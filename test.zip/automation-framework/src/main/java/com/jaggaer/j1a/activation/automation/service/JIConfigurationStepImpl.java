package com.jaggaer.j1a.activation.automation.service;

import java.io.IOException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.net.http.HttpResponse;

import org.ff4j.FF4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jaggaer.j1a.activation.automation.model.AutomationConstants;
import com.jaggaer.j1a.activation.automation.model.JIConfigPayload;
import com.jaggaer.j1a.activation.automation.model.StepExecutionResponse;
import com.jaggaer.j1a.activation.automation.properties.JaggaerOneAnalytics;

@Component
public class JIConfigurationStepImpl 
	implements SingleStepExecution<JIConfigPayload> {

	private static final String SET_COOKIE = "set-cookie";

	@Autowired
	private JaggaerOneAnalytics jaggerOneAnalytics;
	
	@Autowired
	private JIConfigPayload configPayload;
		
	@Autowired
    public FF4j ff4j;

	private String visitorId = "";
	private HttpClient httpClient = null;
	private String jaSessionCookie = "";
	
	public JIConfigurationStepImpl(JaggaerOneAnalytics jaggerOneAnalytics) {
		CookieHandler.setDefault(new CookieManager());

		httpClient = HttpClient.newBuilder()
				.cookieHandler(CookieHandler.getDefault())
				.connectTimeout(Duration.ofSeconds(30))
				.build();
		
		if(jaggerOneAnalytics !=null) {
			this.jaggerOneAnalytics = jaggerOneAnalytics;
		}
		
	}

	public String executePost(String jSessionId) {

		String postData = configPayload.getPOSTBody(); 
		HttpRequest request = HttpRequest.newBuilder()
				.header("Content-Type", "application/x-www-form-urlencoded")
				.header("User-Agent", "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.102 Mobile Safari/537.36 Edg/104.0.1293.70")
				.header(SET_COOKIE, "JSESSIONID=" + jSessionId + ", path=/esop/mdl")
				.header(SET_COOKIE, "VISITORID=" + visitorId + ", path=/esop/mdl")
				.uri(URI.create(					
						ff4j.getPropertiesStore().readProperty(AutomationConstants.JA_ACTION_URL).getValue().toString()))
				.POST(BodyPublishers.ofString(postData))
				.build();

	
		HttpResponse<String> response = null;
		
		try {
			response=httpClient.send(request,BodyHandlers.ofString());
			
			
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
		
		
		return response!=null?response.body():"";
		
	}

	
	public String login() {
		String postData = "userAcct=&customLoginPage=/esop/guest/login.do&gotoPage=&denyUser=&ockedUser=&login=" 
					+ jaggerOneAnalytics.getInstanceUserName() 
					+ "&password=" + jaggerOneAnalytics.getInstancePassword() ;
		
		HttpRequest request = HttpRequest.newBuilder()
								.header("Content-Type", "application/x-www-form-urlencoded")
								.uri(URI.create(					
										ff4j.getPropertiesStore().readProperty(AutomationConstants.JA_INSTANCE_URL).getValue().toString()))
								.POST(BodyPublishers.ofString(postData))
								.build();

		HttpResponse<String> response = null;
		
		try {
			response=httpClient.send(request,BodyHandlers.ofString());
			
			
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}


		String sessionCookie = "";

		if(response != null) {
			visitorId = response.headers().allValues(SET_COOKIE).get(0);
			String [] visitorCookies = visitorId.split(";");
			visitorId = visitorCookies[0];
			visitorCookies = visitorId.split("=");
			visitorId = visitorCookies[1];
	
	
			if(response.headers().allValues(SET_COOKIE).size() > 1)
			{
				sessionCookie = response.headers().allValues(SET_COOKIE).get(1);
				String [] sessionCookies = sessionCookie.split(";");
				sessionCookie = sessionCookies[0];
				sessionCookies = sessionCookie.split("=");
				sessionCookie= sessionCookies[1];
				jaSessionCookie = sessionCookie;
			}
			else
			{
				sessionCookie = jaSessionCookie;
			}
		}
		return sessionCookie;
	}
	
	@Override
	public StepExecutionResponse execute() {
		StepExecutionResponse stepResponse = new StepExecutionResponse();

		if(ff4j.check(AutomationConstants.FEATURE_CONFIGURE_JI))
		{
			String response = login();
			response = executePost(response);
			stepResponse.setResponse(response);
		}
		
		return stepResponse;
	}
}
