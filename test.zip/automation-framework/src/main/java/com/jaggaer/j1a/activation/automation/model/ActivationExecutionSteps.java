package com.jaggaer.j1a.activation.automation.model;

import org.springframework.stereotype.Component;

import com.jaggaer.j1a.activation.automation.service.SingleStepExecution;

import java.util.List;

@Component
public class ActivationExecutionSteps<T> {

	private List<SingleStepExecution<T>> steps;

	public List<SingleStepExecution<T>> getSteps() {
		return steps;
	}

	public void setSteps(List<SingleStepExecution<T>> steps) {
		this.steps = steps;
	}
}
