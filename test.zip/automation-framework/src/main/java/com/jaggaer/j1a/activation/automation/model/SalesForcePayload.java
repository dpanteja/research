package com.jaggaer.j1a.activation.automation.model;


public class SalesForcePayload{

	private String contactID;
	private String applicationUser;
	private String caseDescription;
	public String getContactID() {
		return contactID;
	}
	public void setContactID(String contactID) {
		this.contactID = contactID;
	}
	public String getApplicationUser() {
		return applicationUser;
	}
	public void setApplicationUser(String applicationUser) {
		this.applicationUser = applicationUser;
	}
	public String getCaseDescription() {
		return caseDescription;
	}
	public void setCaseDescription(String caseDescription) {
		this.caseDescription = caseDescription;
	}

}
