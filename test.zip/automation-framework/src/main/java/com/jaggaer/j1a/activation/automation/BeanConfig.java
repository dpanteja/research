package com.jaggaer.j1a.activation.automation;

import java.util.ArrayList;
import java.util.List;

import org.ff4j.FF4j;
import org.ff4j.property.Property;
import org.ff4j.property.PropertyString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.jaggaer.j1a.activation.automation.model.ActivationExecutionSteps;
import com.jaggaer.j1a.activation.automation.model.AutomationConstants;
import com.jaggaer.j1a.activation.automation.model.JDConfigPayload;
import com.jaggaer.j1a.activation.automation.model.JIConfigPayload;
import com.jaggaer.j1a.activation.automation.model.SalesForcePayload;
import com.jaggaer.j1a.activation.automation.service.SingleStepExecution;

@Configuration
public class BeanConfig {
	private static org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(BeanConfig.class); 

	@Autowired
	private SingleStepExecution<SalesForcePayload> sfStep;
	
	@Autowired
	private SingleStepExecution<JDConfigPayload> jdConfigStep;
	
	@Autowired
	private SingleStepExecution<JIConfigPayload> jiConfigStep;
	
	@Autowired
	private FF4j ff4j;
	
	@SuppressWarnings("unchecked")
	@Bean
	public <T> ActivationExecutionSteps<T> activationSteps(){
		logger.info("Initializing Steps....");
		if (!ff4j.getPropertiesStore().existProperty(AutomationConstants.SF_URL_PROPERTY)) {
			ff4j.getPropertiesStore().createProperty((Property<T>) 
					new PropertyString(AutomationConstants.SF_URL_PROPERTY, ""));
        }

		if (!ff4j.getPropertiesStore().existProperty(AutomationConstants.JA_INSTANCE_URL)) {
			ff4j.getPropertiesStore().createProperty((Property<T>) 
					new PropertyString(AutomationConstants.JA_INSTANCE_URL, ""));
        }

		if (!ff4j.getPropertiesStore().existProperty(AutomationConstants.JA_ACTION_URL)) {
			ff4j.getPropertiesStore().createProperty((Property<T>) 
					new PropertyString(AutomationConstants.JA_ACTION_URL, ""));
        }

		ActivationExecutionSteps<T> activationSteps = 
				new ActivationExecutionSteps<>();
		
		List<SingleStepExecution<T>> stepsToExecute = 
				new ArrayList<>();

		stepsToExecute.add((SingleStepExecution<T>) sfStep);
		stepsToExecute.add((SingleStepExecution<T>) jdConfigStep);
		stepsToExecute.add((SingleStepExecution<T>) jiConfigStep);
		
		activationSteps.setSteps(stepsToExecute);
		
		return activationSteps;
	}
	
	@Bean
	public RestTemplate getRESTTemplate() {
		return new RestTemplate();
	}
}
