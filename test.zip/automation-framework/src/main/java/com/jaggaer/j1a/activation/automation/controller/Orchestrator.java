package com.jaggaer.j1a.activation.automation.controller;

import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;

import org.ff4j.FF4j;
import org.ff4j.core.Feature;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jaggaer.j1a.activation.automation.model.StepExecutionResponse;
import com.jaggaer.j1a.activation.automation.service.StepExecutionService;
import com.jaggaer.j1a.activation.automation.model.AutomationConstants;

@RestController
public class Orchestrator {

	@Autowired
	private StepExecutionService executionService;
    
    @Autowired
    public FF4j ff4j;
    
    @PostConstruct
    public void populateAutomationFeature() {
        if (!ff4j.exist(AutomationConstants.FEATURE_CONFIGURE_JD)) {
            ff4j.createFeature(new Feature(AutomationConstants.FEATURE_CONFIGURE_JD, true));
        }
        if (!ff4j.exist(AutomationConstants.FEATURE_CONFIGURE_JI)) {
            ff4j.createFeature(new Feature(AutomationConstants.FEATURE_CONFIGURE_JI, true));
        }
    }
	
	@PostMapping(path = "/executeSteps")
	public ResponseEntity<List<StepExecutionResponse>> executeSteps(){
		List<StepExecutionResponse> responses = 
				executionService.execute();
		
		return new ResponseEntity<> (responses, HttpStatus.OK);
	}
}
